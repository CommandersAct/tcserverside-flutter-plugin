#ifndef __ETCCONSENTSTATE_H__
#define __ETCCONSENTSTATE_H__

typedef enum ETCConsentState
{
    TCPSWaitingForConsent,
    TCPSEnabled,
    TCPSDisabled
} ETCConsentState;

#endif //__ETCCONSENTSTATE_H__
