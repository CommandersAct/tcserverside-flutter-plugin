//
// Created by JeanJulien on 04/11/2016.
// Copyright (c) 2016 TagCommander. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TCCoreInitialisation : NSObject

@end
